# Taksi — dunyo xaritali taksi xizmati

Uch sahifa:
- `/` — yo'lovchi: xaritada A va B nuqtani tanlaydi, narx ko'radi, taksi chaqiradi
- `/driver` — haydovchi: ro'yxatdan o'tadi, onlayn bo'ladi, buyurtma qabul qiladi
- `/admin` — admin panel: hududlar, tariflar, buyurtmalar, haydovchilarni tasdiqlash

## Hududlar qanday ishlaydi
Har bir hudud = markaz nuqta + radius (km) + o'z tarifi (boshlang'ich narx, 1 km narxi, minimal narx, valyuta).
Buyurtma faqat "Qayerdan" nuqtasi biror hudud ichida bo'lsa qabul qilinadi. Haydovchi faqat o'zi turgan hududdagi buyurtmalarni ko'radi.
Yangi hududni admin panel → Hududlar bo'limida xaritani bosib qo'shasiz.

## GitHub'ga yuklash
1. github.com da yangi repozitoriy oching (masalan `taksi`).
2. Shu papkadagi hamma fayllarni yuklang (Add file → Upload files). `public` papkasi bilan birga.

## Render'da ishga tushirish
1. render.com → New → Web Service → GitHub repozitoriyni tanlang.
2. Build Command: `npm install` (yoki bo'sh), Start Command: `node server.js`
3. Environment Variables:
   - `ADMIN_USER` — admin login
   - `ADMIN_PASS` — admin paroli (albatta o'zgartiring, standart `admin123` xavfli!)
4. Deploy. Admin panel: `https://SAYT.onrender.com/admin`

## Ma'lumotlar saqlanishi
Ma'lumotlar `data.json` faylida. Render'ning bepul rejasida fayl har deploy yoki uyqudan keyin o'chishi mumkin.
Doimiy saqlash uchun Render'da Disk qo'shing (Mount Path: `/var/data`) va `DATA_DIR=/var/data` o'zgaruvchisini qo'ying.
Katta loyiha uchun keyinroq PostgreSQL'ga o'tkazish kerak bo'ladi.

## Eslatmalar
- Xarita: OpenStreetMap, manzil qidirish: Nominatim, yo'l: OSRM (hammasi bepul ommaviy xizmatlar, kam yuklama uchun).
  Ko'p foydalanuvchi bo'lsa o'z serveringiz yoki pullik provayder (Mapbox, Google) kerak bo'ladi.
- Haydovchi joylashuvi brauzer GPS orqali olinadi — sahifa ochiq turishi va ruxsat berilgan bo'lishi kerak.
- To'lov hozircha naqd; onlayn to'lov (Payme/Click) qo'shilmagan.
